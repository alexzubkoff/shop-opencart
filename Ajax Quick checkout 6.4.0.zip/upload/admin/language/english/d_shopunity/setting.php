<?php
$_['entry_update']                              = 'Your version is %s';
$_['button_update']                             = 'Check update';
$_['success_no_update']                         = 'Super! You have the latest version.';
$_['warning_new_update']                        = 'Wow! There is a new version available for download.';
$_['error_update']                              = 'Sorry! Something went wrong. If this repeats, contact the support please.';
$_['error_failed']                              = 'Oops! We could not connect to the server. Please try again later.';
