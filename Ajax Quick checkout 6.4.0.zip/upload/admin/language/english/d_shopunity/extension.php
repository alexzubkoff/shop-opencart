<?php
$_['heading_title'] = 'Shopunity';
$_['text_edit'] = 'Extensions';


//errors
$_['error_download'] = 'Oops! We counldn\'t download this extension. The following files seem to be missing.';



$_['text_tester_status_1'] = 'Testing';
$_['text_tester_status_2'] = 'Submitted';
$_['text_tester_status_3'] = 'Error';
$_['text_tester_status_4'] = 'Testing';
$_['text_tester_status_5'] = 'Passed';
$_['text_tester_status_6'] = 'Rejected';

$_['text_new_version_available'] = 'New version is avalible. Please update to: ';